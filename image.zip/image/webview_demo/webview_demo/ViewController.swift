//
//  ViewController.swift
//  webview_demo
//
//  Created by R K University on 28/07/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet var url_add: UITextField!
    @IBOutlet var disp_webview: UIWebView!
    
    var web_url:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        web_url = "https://www.google.com"
        home(add:web_url)
    }
    
    @IBAction func home(_ sender: Any) {
        home(add: "https://www.google.com")
    }
    
    @IBAction func reload_web_page(_ sender: Any) {
        disp_webview.reload()
    }
    
    @IBAction func load_web_page(_ sender: Any) {
        let user_url = url_add.text!
        if(!user_url.contains("https:") && user_url.contains(".com")){
            web_url = "https:" + url_add.text!
        }else if(!user_url.contains("https:") && user_url.contains(".com")){
            web_url = "https://www." + url_add.text!
        }else if(!user_url.contains("https:") && !user_url.contains(".com")){
            web_url = "https://www.google.com/search?q=\(user_url)"
        }
        home(add: web_url)
    }
    
    
    func home(add:String){
        let iurl = URL(string:add)
        disp_webview.loadRequest(URLRequest(url: iurl!))
    }

}

