//
//  ViewController.swift
//  weather_api
//
//  Created by R K University on 15/09/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var cityName: UITextField!
    
    @IBOutlet var c_temp: UILabel!
    @IBOutlet var min_temp: UILabel!
    @IBOutlet var max_temp: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func find_weather(_ sender: Any) {
        let iurl = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(cityName.text!)&appid=c0c732ed409d96519c68428ed3ea11f4")
        
        let task = try! URLSession.shared.dataTask(with: iurl!, completionHandler: {
            (data, URLResponse, error) in
            let jsonData = try! JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String:Any]
            let mainData = jsonData["main"] as! NSDictionary
            
            let tempData = mainData["temp"] as! Double
            let tempMinData = mainData["temp_min"] as! Double
            let tempMaxData = mainData["temp_max"] as! Double
            
            self.c_temp.text = "Current Temp: \(round(tempData - 273.15)) °C"
            self.max_temp.text = "Max Temp: \(round(tempMinData - 273.15)) °C"
            self.min_temp.text = "Min Temp: \(round(tempMaxData - 273.15)) °C"
        })
        task.resume()
    }

}

