//
//  ViewController.swift
//  TableViewContent
//
//  Created by R K University on 06/09/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit
//UI - swift  -- datasource, delegate UITableViewDelegate(click), UITableViewDataSource(func no of rows and cellforRowat(cell-value))
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var list = ["Apple", "Samsung", "Sony", "Oppo", "Vivo"]
    //func -- number of rows()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    //func -- define cell and it's value
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell.init(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = list[indexPath.row]
        return cell
    }
    
    //func -- select cell (table view did select row at)
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print(indexPath.row) //to get index number.
        //print(list[indexPath.row]) //to get value.
        
        let selectedvalue = list[indexPath.row]
        let alert = UIAlertController(title: "Product List", message: "You have selected \(selectedvalue)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

