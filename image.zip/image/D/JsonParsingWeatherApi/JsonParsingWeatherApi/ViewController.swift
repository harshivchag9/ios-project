//
//  ViewController.swift
//  JsonParsingWeatherApi
//
//  Created by R K University on 17/09/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var CitgyName: UITextField!
    
    @IBOutlet weak var MinTemp: UILabel!
    @IBOutlet weak var MaxTemp: UILabel!
    @IBOutlet weak var CurrentTemp: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func Submit(_ sender: Any) {
        //to find weather
        //step-1 define the url of api with api key
        //let iurl = URL(string:"https://api.openweathermap.org/data/2.5/weather?q=Rajkot&APPID=be06d1bf2c226a7fa8672ea0ebf2b225")
        let iurl = URL(string:"https://api.openweathermap.org/data/2.5/weather?q=\(CitgyName.text!)&APPID=be06d1bf2c226a7fa8672ea0ebf2b225")
        
        //step-2 create task URLSessiontask
        let task = try! URLSession.shared.dataTask(with: iurl!, completionHandler:
        {
            (data,URLResponse,error) in
            let jsonData = try! JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String:Any]
            
            //to the api all temp inside "main" key
            let MainData = jsonData["main"] as! NSDictionary
            
            //inside main temp in "temp" key
            let tempData = MainData["temp"] as! Double
            var temp = tempData - 273.15
            
            //inside main max temp in "temp_max" key
            let tempMaxData = MainData["temp_max"] as! Double
            var maxtemp = tempMaxData - 273.15
            
            //inside main max temp in "temp_min" key
            let tempMinData = MainData["temp_min"] as! Double
            var mintemp = tempMinData - 273.15
            
            self.CurrentTemp.text = "Current temp :  \(temp) "
            self.MaxTemp.text = "Max temp : \(maxtemp) "
            self.MinTemp.text = "Min temp : \(mintemp) "
            
            print(temp)
            print(maxtemp)
            print(mintemp)
        })
        task.resume()
    }
}

