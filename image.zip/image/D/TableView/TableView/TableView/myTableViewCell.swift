//
//  myTableViewCell.swift
//  TableView
//
//  Created by RKU on 21/07/21.
//  Copyright © 2021 RKU. All rights reserved.
//

import UIKit

class myTableViewCell: UITableViewCell {
    @IBOutlet var myimage: UIImageView!
    @IBOutlet var mysubtitle: UILabel!
    @IBOutlet var mytitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
