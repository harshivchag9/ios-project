//
//  ViewController.swift
//  TableView
//
//  Created by RKU on 21/07/21.
//  Copyright © 2021 RKU. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
   let imgArray = ["java.png","kotlin.png","php.png","python.png","ruby.png","swift.png"]
    let titleArray = ["Java","Kotlin","php","Python","Ruby","Swift"]
    let subtitleArray = ["1","2","3","4","5","6"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        cell.myimage.image = UIImage(named : imgArray[indexPath.row])
        cell.mytitle.text = titleArray[indexPath.row]
        cell.mysubtitle.text = subtitleArray[indexPath.row]
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

