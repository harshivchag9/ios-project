//
//  ViewController.swift
//  databaseharsh
//
//  Created by RKU on 10/09/21.
//  Copyright © 2021 rku. All rights reserved.
//

import UIKit
import  SQLite3

class ViewController: UIViewController {
    
    
    @IBOutlet var surName: UITextField!
    @IBOutlet var name: UITextField!
    var dpointer:OpaquePointer?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        createdb()
        createTable()
    }

    func createdb(){
        let file = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("testDB.sqlite")
        
        sqlite3_open(file.path, &dpointer)
    }
    func createTable(){
        
        var ct = "create table if not exists emp (name text, surName text)"
        if sqlite3_exec(dpointer, ct, nil, nil, nil) == SQLITE_OK
        {
            print("Table Created....")
        }
        
    }
    @IBAction func btnLogin(_ sender: Any) {
        
        var inq = "insert into emp values('\(name.text!)','\(surName.text!)')"
        if sqlite3_exec(dpointer, inq, nil, nil, nil) == SQLITE_OK
        {
            print("Record inserted...!!")
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
        
    }


}

