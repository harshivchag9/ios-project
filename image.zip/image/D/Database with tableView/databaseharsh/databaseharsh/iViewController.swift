//
//  iViewController.swift
//  databaseharsh
//
//  Created by RKU on 10/09/21.
//  Copyright © 2021 rku. All rights reserved.
//

import UIKit
import SQLite3
class iViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var dpointer:OpaquePointer?
    var fpointer:OpaquePointer?
    var tempArray = [String]()
    @IBOutlet var myTableView: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return tempArray.count
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = tempArray[indexPath.row]
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let file = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("testDB.sqlite")
        
        sqlite3_open(file.path, &dpointer)
        
        if sqlite3_prepare(dpointer, "select * from emp", -1, &fpointer, nil) == SQLITE_OK
        {
            while(sqlite3_step(fpointer) == SQLITE_ROW)
            {
                var name = String(cString:sqlite3_column_text(fpointer, 0))
                var surname = String(cString:sqlite3_column_text(fpointer, 1))
                var fname = "\(name) \(surname)"
                tempArray.append(fname)
                print(tempArray)
                DispatchQueue.main.async{self.myTableView.reloadData()}
                
            }
        }
        
    }

}
