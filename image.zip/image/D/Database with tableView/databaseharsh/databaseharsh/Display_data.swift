//
//  Display_data.swift
//  databaseharsh
//
//  Created by RKU on 10/09/21.
//  Copyright © 2021 rku. All rights reserved.
//

import UIKit

class Display_data: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
