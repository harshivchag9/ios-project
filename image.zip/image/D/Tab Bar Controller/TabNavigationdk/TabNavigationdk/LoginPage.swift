//
//  LoginPage.swift
//  TabNavigationdk
//
//  Created by RKU on 06/08/21.
//  Copyright © 2021 RKU. All rights reserved.
//

import UIKit

class LoginPage: UITableViewCell {

    @IBOutlet var uname: UITextField!
    @IBOutlet var password: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization
    
    
    }
    
    @IBAction func Submit(_ sender: Any) {
        if(uname.text! == "admin" && password.text! == "1234"){
            jump()
        }
    }
    
    func jump(){
    
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
