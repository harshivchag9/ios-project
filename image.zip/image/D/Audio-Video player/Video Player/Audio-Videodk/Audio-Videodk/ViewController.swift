//
//  ViewController.swift
//  Audio-Videodk
//
//  Created by RKU on 18/08/21.
//  Copyright © 2021 RKU. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class ViewController: UIViewController {


    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func StartVideo(_ sender: Any) {
        guard let filePath = Bundle.main.path(forResource: "sampleVideo", ofType: "mp4") else { return}
        
        let player = AVPlayer(url: URL(fileURLWithPath: filePath))
        let vc = AVPlayerViewController()
        
        vc.player = player
        
        present(vc, animated: true)
    }
    
}

