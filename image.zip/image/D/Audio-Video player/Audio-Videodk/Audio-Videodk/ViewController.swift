//
//  ViewController.swift
//  Audio-Videodk
//
//  Created by RKU on 18/08/21.
//  Copyright © 2021 RKU. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class ViewController: UIViewController {

    var audioPlayer:AVAudioPlayer?

    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //path
        let path = Bundle.main.path(forResource: "sampleSound", ofType: "mp3")
        //player
        do{
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
        }catch{
            print(error)
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func PlayMusic(_ sender: Any) {
        
       //play
        audioPlayer?.play()
        
    }
    
    @IBAction func StopMusic(_ sender: Any) {
        audioPlayer?.stop()
    }
}

