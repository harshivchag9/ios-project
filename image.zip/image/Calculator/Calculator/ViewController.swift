//
//  ViewController.swift
//  Calculator
//
//  Created by R K University on 21/07/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var digit1: UITextField!
    @IBOutlet weak var digit2: UITextField!
    @IBOutlet weak var ansLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //buttons action key -- do not create btn's outlet initially.
    @IBAction func addition(_ sender: Any) {
        let a = digit1.text!
        let b = digit2.text!
        
        let c = Int(a)! + Int(b)!
        
        //to print addition of digit1 & digit2
        ansLabel.text = "Answer = \(c)"
    }
    
    @IBAction func subtraction(_ sender: Any) {
        ansLabel.text = "Answer = \(Int(digit1.text!)! - Int(digit2.text!)!)"
    }
    
    @IBAction func multiplication(_ sender: Any) {
        ansLabel.text = "Answer = \(Int(digit1.text!)! * Int(digit2.text!)!)"
    }
    
    @IBAction func division(_ sender: Any) {
        ansLabel.text = "Answer = \(Double(digit1.text!)! / Double(digit2.text!)!)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

