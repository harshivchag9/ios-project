//
//  ViewController.swift
//  avplayer
//
//  Created by R K University on 18/08/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {

    var iplayer: AVAudioPlayer?
    var v_oplayer: AVPlayer? //for offline video player
    var isPlaying = false
    var timer:Timer!
    
    @IBOutlet var playedTime: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Offline Song File
        let path = Bundle.main.path(forResource: "applering", ofType: "mp3")
        iplayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
        
        //Online Song File
        //let path = URL(string: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3")
        //iplayer = try! AVAudioPlayer(contentsOf: path)
    }

    @IBAction func playorpause(_ sender: Any) {
        if isPlaying {
            iplayer?.pause()
            isPlaying = false
        } else {
            iplayer?.play()
            isPlaying = true
            
            timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        }
    }
    
    @objc func updateTime() {
        let currentTime = Int((iplayer?.currentTime)!)
        let minutes = currentTime/60
        let seconds = currentTime - minutes * 60
        
        playedTime.text = String(format: "%02d:%02d", minutes,seconds) as String
    }
    
    @IBAction func stopplayer(_ sender: Any) {
        iplayer?.stop()
        iplayer?.currentTime = 0
        isPlaying = false
    }
    
    @IBAction func playvideo(_ sender: Any) {
        //v_oplayer = Bundle.main.path(forResource: "videoname", ofType: "mp4")
        let v_player = AVPlayer(url: URL(string: "https://bit.ly/swswift")!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = v_player
        present(playerViewController, animated: true, completion: nil)
    }
}

