//
//  ViewController.swift
//  tab_bar_db
//
//  Created by R K University on 08/09/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit
import SQLite3

class ViewController: UIViewController {

    var dpointer:OpaquePointer?
    
    @IBOutlet var name: UITextField!
    @IBOutlet var surname: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createdb()
        createtable()
    }
    
    func createdb(){
        let file = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("userDB.sqlite")
        
        sqlite3_open(file.path, &dpointer)
    }
    
    func createtable(){
        var ct = "create table if not exists users (name text, surname text)"
        if sqlite3_exec(dpointer, ct, nil, nil, nil) == SQLITE_OK
        {
            print("Table Created")
        }
    }
    
    @IBAction func save_data(_ sender: Any) {
        var inq = "insert into users values('\(name.text!)','\(surname.text!)')"
        if sqlite3_exec(dpointer, inq, nil, nil, nil) == SQLITE_OK
        {
            print("Record Inserted")
        }
    }
    

}

