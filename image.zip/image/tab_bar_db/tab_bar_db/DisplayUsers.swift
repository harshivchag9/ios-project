//
//  DisplayUsers.swift
//  tab_bar_db
//
//  Created by R K University on 08/09/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit
import SQLite3

class DisplayUsers: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tempArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = tempArr[indexPath.row]
        return cell
    }
    
    var dpointer:OpaquePointer?
    var fpointer:OpaquePointer?
    var tempArr = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tempArr = [String]()
        let file = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("userDB.sqlite")
        
        sqlite3_open(file.path, &dpointer)
        
        if sqlite3_prepare(dpointer, "select * from users", -1, &fpointer, nil) == SQLITE_OK
        {
            while(sqlite3_step(fpointer) == SQLITE_ROW)
            {
                var name = String(cString: sqlite3_column_text(fpointer, 0))
                var surname = String(cString: sqlite3_column_text(fpointer, 1))
                var fname = "\(name) \(surname)"
                tempArr.append(fname)
                print(tempArr)
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
    }
    
}
