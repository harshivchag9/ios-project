//
//  ViewController.swift
//  LoginScale
//
//  Created by R K University on 21/07/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //Objects
    //Outlet and Action
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    
    //Load - Once - animation(visible) - first page - start page
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //Appears - Multiple - No -current state
    override func viewDidAppear(_ animated: Bool) {
        label1.font = label1.font.withSize(15)
        //size the widget
        label2.font = label2.font.withSize(self.view.frame.height * 0.03)
        label3.font = label3.font.withSize(self.view.frame.height * 0.03)
    }
    

}

