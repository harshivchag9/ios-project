//
//  ViewController.swift
//  AlertMe
//
//  Created by R K University on 21/07/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    var counter = 5
    
    //First Alert button
    @IBAction func showalert(_ sender: Any) {
        var choice = 1

        //Parameters for UIAlertController are (Title, msg, type: alert, actionSheet)
        let alert = UIAlertController(title: "Warning", message: "Do you want to go ahead...", preferredStyle: .alert)

        //to add action buttons to alert
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {ACTION in
            choice = 1
            print("You have selected Yes :",choice)
        })) //positive
        alert.addAction(UIAlertAction(title: "No", style: .default, handler: {ACTION in
            choice = 0
            print("You have selected No :",choice)
        })) //negative

        //to show alert
        self.present(alert, animated: true, completion: nil)
    }
    
    //Second Alert button
    @IBAction func multiOptionAlert(_ sender: Any) {
        let multiOptionalert = UIAlertController(title: "KBC", message: "Who is our PM?", preferredStyle: .actionSheet) //.alert will show dailog at center whereas .actionsheet at bottom.
        //options as action
        multiOptionalert.addAction(UIAlertAction(title: "A). Narendra Modi", style: .default, handler: {ACTION in
            print("You answer is correct..!!")
        }))
        multiOptionalert.addAction(UIAlertAction(title: "B). Vijay Rupani", style: .default, handler: nil))
        multiOptionalert.addAction(UIAlertAction(title: "C). Amit Shah", style: .default, handler: nil))
        multiOptionalert.addAction(UIAlertAction(title: "D). Dhaval Nimavat", style: .default, handler: nil))
        
        self.present(multiOptionalert, animated: true, completion: nil)
    }
    
    //Third Alert button
    let timeralert = UIAlertController(title: "Warning", message: "This message will be deleted after sec...", preferredStyle: .alert)

    @IBAction func timerAlert(_ sender: Any) {
        call_alert()
        let timer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(dismiss_alert), userInfo: nil, repeats: false)
        //timer.invalidate()
    }
    func call_alert(){
        self.present(timeralert, animated: true, completion: nil)
    }
    @objc func dismiss_alert(){
        timeralert.dismiss(animated: true, completion: nil)
    }
    
    //Fourth Alert button
    @IBAction func form_alert(_ sender: Any) {
        //login_form_modal()
        captcha()
    }
    
    func captcha (){
        let c_alert = UIAlertController(title: "PUZZLE 1", message: "Identify the above image.", preferredStyle: .alert)
        
        var img = UIImageView(frame: CGRect(x: 220, y: 10 , width: 40, height: 40))
        img.image = UIImage(named: "bg.jpg")
        
        c_alert.view.addSubview(img)
        c_alert.addTextField()
        c_alert.textFields![0].placeholder = "Enter the value"
        
        c_alert.addAction(UIAlertAction(title: "Submit", style: .default, handler: nil))
        c_alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        self.present(c_alert, animated: true, completion: nil)
    }
    
    func login_form_modal() {
        let modal_alert = UIAlertController(title: "Login", message: "Enter your username and password below.", preferredStyle: .alert)
        
        modal_alert.addTextField()
        modal_alert.textFields![0].placeholder = "Username"
        modal_alert.addTextField()
        modal_alert.textFields![1].placeholder = "Password"
        modal_alert.textFields![1].isSecureTextEntry = true
        
        modal_alert.addAction(UIAlertAction(title: "Submit", style: .default, handler:{
            ACTION in
            //logic to check admin 123
            if modal_alert.textFields![0].text == "admin"{
                if modal_alert.textFields![1].text == "123"{
                    print("You are valid user")
                }else{
                    print("Incorrect Password")
                }
            }else{
                print("Incorrect username and password")
            }
        }))
        modal_alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        self.present(modal_alert, animated: true, completion: nil)
    }

}

