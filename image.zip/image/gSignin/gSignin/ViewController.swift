//
//  ViewController.swift
//  gSignin
//
//  Created by R K University on 21/09/21.
//  Copyright © 2021 com. All rights reserved.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController, GIDSignInDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        GIDSignIn.sharedInstance().clientID = "197883465133-jmrgqanp728f7104luvn9e25kdti3rvg.apps.googleusercontent.com"
//        GIDSignIn.sharedInstance()?.delegate = self
    }
    
    

    @IBAction func signIn(_ sender: Any) {
//        GIDSignIn.sharedInstance()?.presentingViewController = self
//        GIDSignIn.sharedInstance()?.signIn()
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if (error == nil)
        {
            var name = user.profile.name
            print(name)
            
            let userId = user.userID
            print (userId)
            
            let idToken = user.authentication.idToken
            print (idToken)
            
            let givenName = user.profile.givenName
            print(givenName)
            
            let familyName = user.profile.familyName
            let email = user.profile.email
            print(email)
            
            let purl = user.profile.imageURL(withDimension: 120)
            print (purl)
            
        }
        else
        {
            print("Please connect to the network")
        }
    }
    
}

